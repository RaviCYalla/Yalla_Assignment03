package finalConstr_7;

public class MyClass {
	 private final String name;
	 
	 public MyClass(String name) {
	        this.name = name;
	        System.out.println("Creating MyClass object with name: " + name);
	    }

	   

	    // Final constructor that cannot be overridden
//	    public final MyClass() {
//	        this.name = "Default";
//	        System.out.println("Creating default MyClass object");
//	    }

		

}
