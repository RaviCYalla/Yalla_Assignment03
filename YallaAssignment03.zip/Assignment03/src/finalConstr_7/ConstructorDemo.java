package finalConstr_7;

public class ConstructorDemo {
	  public static void main(String[] args) {
	        MyClass obj1 = new MyClass("Obj1");
//	        MyClass obj2 = new MyClass();
//	        MySubclass obj3 = new MySubclass();
	    }

}
