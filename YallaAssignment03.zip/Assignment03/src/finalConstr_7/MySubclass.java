package finalConstr_7;

//public class MySubclass extends MyClass {

	
	
	 // Compiler error as we cannot override final constructor
//    public MySubclass() {
//        super();
//    }

//}
