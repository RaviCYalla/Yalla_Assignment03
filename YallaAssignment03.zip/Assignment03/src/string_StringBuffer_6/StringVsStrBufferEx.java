package string_StringBuffer_6;

public class StringVsStrBufferEx {
    public static void main(String[] args) {
        // Using String
        String str = "Hello";
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++) {
            str += " world";
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Time taken by String: " + (endTime - startTime) + " ms");

        // Using StringBuffer
        StringBuffer sbf = new StringBuffer("Hello");
        startTime = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++) {
            sbf.append(" world");
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuffer: " + (endTime - startTime) + " ms");
    }
}
