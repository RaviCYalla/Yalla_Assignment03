package accessModifiers_2;

public class Cat extends Animal{
	 public void makeSound() {
	        System.out.println("Cat is meowing");
	    }

}
