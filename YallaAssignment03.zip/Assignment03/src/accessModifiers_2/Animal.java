package accessModifiers_2;

public class Animal {
	 public void makeSound() {
	        System.out.println("Animal is making a sound");
	    }

}
