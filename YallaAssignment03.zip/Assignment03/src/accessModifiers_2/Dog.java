package accessModifiers_2;

public class Dog extends Animal {

	 public void makeSound() {
	        System.out.println("Dog is barking");
	    }
}
