package accessModifiers_2;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Animal animal = new Animal();
	        Dog dog = new Dog();
	        Cat cat = new Cat();

	        animal.makeSound(); 
	        dog.makeSound(); 
	        cat.makeSound(); 
	    }

	}

