package createThreads_19;

public class Thread_Driver {
	public static void main(String[] args) {
        MyThread myThread = new MyThread();
        myThread.start();

}
}
