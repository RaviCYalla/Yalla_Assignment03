package createThreads_19;

public class RunnableDriver {
	
	 public static void main(String[] args) {
	        MyRunnable myRunnable = new MyRunnable();
	        Thread thread = new Thread(myRunnable);
	        thread.start();
	    }

}
