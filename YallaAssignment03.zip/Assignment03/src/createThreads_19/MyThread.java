package createThreads_19;

public class MyThread extends Thread {
    public void run() {
        System.out.println("Thread started.");
    }
}

