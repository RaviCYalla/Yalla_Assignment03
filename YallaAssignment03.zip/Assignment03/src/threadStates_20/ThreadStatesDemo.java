package threadStates_20;

public class ThreadStatesDemo {
    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(() -> {
            System.out.println("Thread running...");
        });

        System.out.println("Thread state after creating: " + t.getState());

        t.start();
        System.out.println("Thread state after starting: " + t.getState());

        Thread.sleep(1000);
        System.out.println("Thread state after sleeping: " + t.getState());

        t.join();
        System.out.println("Thread state after joining: " + t.getState());
    }
}
