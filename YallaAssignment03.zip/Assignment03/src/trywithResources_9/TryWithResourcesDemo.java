package trywithResources_9;


import java.io.*;

public class TryWithResourcesDemo {
    public static void main(String[] args) {
        try (FileInputStream file = new FileInputStream("words.txt")) {
            int data = file.read();
            while (data != -1) {
                System.out.print((char) data);
                data = file.read();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}