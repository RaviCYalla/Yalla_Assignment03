package singleton_26;

public class SingletonDriver {
    public static void main(String[] args) {
        // Attempt to create multiple instances of Singleton
        SingletonEx instance1 = SingletonEx.getInstance();
        SingletonEx instance2 = SingletonEx.getInstance();
        
        // Print out the object reference for each instance
        System.out.println("Instance 1: " + instance1);
        System.out.println("Instance 2: " + instance2);
        
        // Check if both instances refer to the same object
        if (instance1 == instance2) {
            System.out.println("Both instances refer to the same object.");
        } else {
            System.out.println("Both instances refer to different objects.");
        }
    }
}
