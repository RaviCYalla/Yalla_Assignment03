package singleton_26;

public class SingletonEx {
    private static final SingletonEx INSTANCE = new SingletonEx();
    
    private SingletonEx() {
    }
    
    public static SingletonEx getInstance() {
        return INSTANCE;
    }
    
    public void doSomething() {
        // singleton method implementation
    	System.out.println("implementation");
    }
}
