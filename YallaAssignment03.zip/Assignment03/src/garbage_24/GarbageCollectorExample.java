package garbage_24;

public class GarbageCollectorExample {
    public static void main(String[] args) {
        
        Object obj = new Object();
        
        // Set the reference to null to make the object eligible for garbage collection
        obj = null;
        
        // Call the garbage collector explicitly
        System.gc();
    }
}

// As mentioned earlier, it is not possible to explicitly
//trigger the garbage collector. Therefore, there is no output to be shown.