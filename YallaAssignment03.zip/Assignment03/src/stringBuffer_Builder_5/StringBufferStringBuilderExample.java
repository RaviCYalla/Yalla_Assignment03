package stringBuffer_Builder_5;


public class StringBufferStringBuilderExample {
    public static void main(String[] args) {
        StringBuffer sbf = new StringBuffer("Hello");
        StringBuilder sbd = new StringBuilder("Hello");
        
        // Append a million " world" strings to both objects
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            sbf.append(" world");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuffer: " + (endTime - startTime) + " ms");
        
        startTime = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            sbd.append(" world");
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time taken by StringBuilder: " + (endTime - startTime) + " ms");
    }
}
