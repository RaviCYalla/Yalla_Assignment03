package fFFinal_12;


public class FinalExample {
    private static final int x = 10;
    private int y;
    
    public FinalExample(int y) {
        this.y = y;
    }
    
    public static void main(String[] args) {
        FinalExample example = new FinalExample(20);
        example.printValues();
        example = null;
        System.gc();
    }
    
    public void printValues() {
        System.out.println("x = " + x);
        System.out.println("y = " + y);
        try {
            int[] arr = new int[3];
            System.out.println("arr[4] = " + arr[4]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Exception caught");
            return;
        } finally {
            System.out.println("In finally block");
        }
    }
    
    @Override
    protected void finalize() throws Throwable {
        System.out.println("In finalize method");
    }
}
