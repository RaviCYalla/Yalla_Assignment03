package al_Sync_14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SynchronizedArrayListExample {

    public static void main(String[] args) {
        // Creating a non-synchronized ArrayList
        List<String> list = new ArrayList<String>();

        // Adding elements to the list
        list.add("Java");
        list.add("Python");
        list.add("C++");

        // Synchronizing the list using Collections.synchronizedList() method
        List<String> synchronizedList = Collections.synchronizedList(list);

        // Synchronizing the list using synchronized keyword
        List<String> synchronizedList2 = new ArrayList<String>();
        synchronized(synchronizedList2) {
            synchronizedList2.addAll(list);
        }

        // Synchronizing specific methods of the list using synchronized keyword
        List<String> synchronizedList3 = new ArrayList<String>();
        synchronized(synchronizedList3) {
            synchronizedList3.addAll(list);
            String element = synchronizedList3.get(0);
            // Accessing element at index 0 in synchronized manner
            System.out.println("Element at index 0: " + element);
        }
    }
}
