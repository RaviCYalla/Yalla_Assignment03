package overrideSP_4;

public class DriverClass {

	public static void main(String[] args) {
		
		 Animal animal = new Animal();
	        Dog dog = new Dog();

	        // cannot access private method
	        // animal.makeSound();

	        // should call static method using class name
	        Animal.run();
	        Dog.run();
	     
	    }

}
