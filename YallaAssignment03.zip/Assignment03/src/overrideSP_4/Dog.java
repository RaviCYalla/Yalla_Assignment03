package overrideSP_4;

public class Dog extends Animal{

	

	// cannot override private method and static method
    
}
