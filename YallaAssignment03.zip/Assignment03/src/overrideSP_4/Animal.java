package overrideSP_4;

public class Animal {
	 private void makeSound() {
	        System.out.println("Animal is making a sound");
	    }

	   

		public static void run() {
			// TODO Auto-generated method stub
			 System.out.println("Animal is running");
			
		}

}
