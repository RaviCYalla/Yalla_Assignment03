package immutable_22;

import java.util.ArrayList;
import java.util.List;

public class ImmutableExampleTest {
    public static void main(String[] args) {
        List<String> hobbies = new ArrayList<>();
        hobbies.add("reading");
        hobbies.add("running");
        ImmutableExample example = new ImmutableExample(1, "John Doe", hobbies);

        // Print out fields of the immutable object
        System.out.println("Id: " + example.getId());
        System.out.println("Name: " + example.getName());
        System.out.println("Hobbies: " + example.getHobbies());

        // Attempt to modify the List of hobbies
        example.getHobbies().add("swimming");

        // Print out hobbies to show that it hasn't been modified
        System.out.println("Hobbies after modification: " + example.getHobbies());
    }
}




