package immutable_22;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ImmutableExample {
    private final int id;
    private final String name;
    private final List<String> hobbies;

    public ImmutableExample(int id, String name, List<String> hobbies) {
        this.id = id;
        this.name = name;
        this.hobbies = Collections.unmodifiableList(new ArrayList<>(hobbies));
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<String> getHobbies() {
        return hobbies;
    }
}
