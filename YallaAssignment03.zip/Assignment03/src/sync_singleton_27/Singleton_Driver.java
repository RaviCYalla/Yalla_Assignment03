package sync_singleton_27;


public class Singleton_Driver {
public static void main(String[] args) {
   // create two instances of Singleton class
   Singleton s1 = Singleton.getInstance();
   Singleton s2 = Singleton.getInstance();

   // check if both instances are the same
   if (s1 == s2) {
       System.out.println("Both instances are same");
   } else {
       System.out.println("Both instances are not same");
   }
}
}