package throwsClause_10;

import java.io.IOException;

public class SuperClass {
	

	public void doSomething()  throws IOException, InterruptedException{
		// TODO Auto-generated method stub
		
	}

}
