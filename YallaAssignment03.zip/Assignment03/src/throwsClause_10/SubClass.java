package throwsClause_10;
	
	class SubClass extends SuperClass {
	    // Override the doSomething() method of SuperClass
	    public void doSomething() throws InterruptedException {
	        // some code that throws InterruptedException only
	    }

		
}
