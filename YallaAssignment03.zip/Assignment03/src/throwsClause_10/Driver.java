package throwsClause_10;

import java.io.IOException;

public class Driver {
	
	 public static void main(String[] args) {
	        SuperClass s = new SuperClass();
	        try {
	           s.doSomething();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        SubClass sub = new SubClass();
	        try {
	            sub.doSomething();
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}


