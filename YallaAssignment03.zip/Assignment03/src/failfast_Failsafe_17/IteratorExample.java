package failfast_Failsafe_17;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class IteratorExample {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        names.add("John");
        names.add("Peter");
        names.add("Mary");

        Iterator<String> iterator = names.iterator();

        // Fail-Fast iterator example
        while (iterator.hasNext()) {
            String name = iterator.next();
            System.out.println(name);
            names.remove(name); // concurrent modification
        }

        // Fail-Safe iterator example
        names = new CopyOnWriteArrayList<>(names);
        iterator = names.iterator();

        while (iterator.hasNext()) {
            String name = iterator.next();
            System.out.println(name);
            names.add("Paul"); // concurrent modification
        }
    }
}
