package HashTableVsHashMap_15;

import java.util.Hashtable;
import java.util.HashMap;

public class Hash_table_Map {
    public static void main(String[] args) {
        
        Hashtable<String, Integer> ht = new Hashtable<>();

        ht.put("John", 25);
        ht.put("Jane", 30);
        ht.put("Alex", 35);
        ht.put("Mary", 40);

        System.out.println("Value of John in HashTable: " + ht.get("John"));

        HashMap<String, Integer> hm = new HashMap<>();
 
        hm.put("John", 25);
        hm.put("Jane", 30);
        hm.put("Alex", 35);
        hm.put("Mary", 40);

        System.out.println("Value of John in HashMap: " + hm.get("John"));
    }
}
