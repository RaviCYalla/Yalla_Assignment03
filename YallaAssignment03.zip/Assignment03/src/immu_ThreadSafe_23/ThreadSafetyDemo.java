package immu_ThreadSafe_23;

public class ThreadSafetyDemo {
    public static void main(String[] args) {
        ImmutablePerson person = new ImmutablePerson("John", "Doe");
        
        Runnable task = () -> {
            System.out.println(Thread.currentThread().getName() + ": First name is " + person.getFirstName());
            System.out.println(Thread.currentThread().getName() + ": Last name is " + person.getLastName());
        };
        
       
        Thread t1 = new Thread(task, "Thread 1");
        Thread t2 = new Thread(task, "Thread 2");
        Thread t3 = new Thread(task, "Thread 3");
        
      
        t1.start();
        t2.start();
        t3.start();
    }
}

