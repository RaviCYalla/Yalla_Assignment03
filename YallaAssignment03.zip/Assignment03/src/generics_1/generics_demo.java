package generics_1;

public class generics_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box<String> stringBox = new Box<>();
		stringBox.setValue("Hello");
		System.out.println(stringBox.getValue()); 

		Box<Integer> intBox = new Box<>();
		intBox.setValue(42);
		System.out.println(intBox.getValue()); 


	}

}
