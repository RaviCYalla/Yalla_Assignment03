package uml_11;


public class Driver {
	   public static void main(String[] args) {
	      Address address = new Address("123 Main St", "Anytown", "CA");
	      Person person = new Person("John Doe", 30, address);

	      // Access data in the person and address objects
	      System.out.println(person.getName());
	      System.out.println(person.getAddress().getCity());
	   }
	}
