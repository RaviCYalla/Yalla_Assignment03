package tryWithoutCatch_8;

import java.io.*;

import java.io.*;

public class TryWithoutCatchDemo {
    public static void main(String[] args) throws IOException {
        FileReader file = null;
        try {
            file = new FileReader("words.txt");
            BufferedReader reader = new BufferedReader(file);
            String line = reader.readLine();
            while (line != null) {
                System.out.println(line);
                line = reader.readLine();
            }
        } finally {
            if (file != null) {
                try {
                    file.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Inside finally block");
        }
    }
}
