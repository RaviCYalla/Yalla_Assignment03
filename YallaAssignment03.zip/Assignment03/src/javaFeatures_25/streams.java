package javaFeatures_25;

import java.util.*;
import java.util.stream.Collectors;

public class streams {
	public static void main(String args[]) {

List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David", "Emily");
List<String> result = names.stream()
                           .filter(s -> s.startsWith("A") || s.startsWith("E"))
                           .map(String::toUpperCase)
                           .collect(Collectors.toList());

System.out.println(result);

}
}