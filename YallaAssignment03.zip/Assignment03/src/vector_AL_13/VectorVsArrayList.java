package vector_AL_13;

import java.util.ArrayList;
import java.util.Vector;

public class VectorVsArrayList {
    public static void main(String[] args) {
        Vector<Integer> vector = new Vector<>();
        ArrayList<Integer> arrayList = new ArrayList<>();

        System.out.println("Vector capacity: " + vector.capacity()); // default capacity is 10
        System.out.println("ArrayList capacity: " + arrayList.size()); // no initial capacity

        long vectorStart = System.nanoTime();
        for (int i = 0; i < 1000000; i++) {
            vector.add(i);
        }
        long vectorEnd = System.nanoTime();

        long arrayListStart = System.nanoTime();
        for (int i = 0; i < 1000000; i++) {
            arrayList.add(i);
        }
        long arrayListEnd = System.nanoTime();

        System.out.println("Vector time taken: " + (vectorEnd - vectorStart) + "ns");
        System.out.println("ArrayList time taken: " + (arrayListEnd - arrayListStart) + "ns");

        vector.clear();
        arrayList.clear();

        System.out.println("Vector size: " + vector.size());
        System.out.println("ArrayList size: " + arrayList.size());

        vector.add(1);
        vector.add(2);
        vector.add(3);
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);

        System.out.println("Vector: " + vector);
        System.out.println("ArrayList: " + arrayList);

        vector.removeElementAt(1);
        arrayList.remove(1);

        System.out.println("Vector after removing element at index 1: " + vector);
        System.out.println("ArrayList after removing element at index 1: " + arrayList);
    }
}

