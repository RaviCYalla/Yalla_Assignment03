package covariant_3;

public class Dog extends Animal {
	  @Override
	    public Dog getAnimal() {
	        System.out.println("Dog class");
	        return new Dog();
	    }

}
