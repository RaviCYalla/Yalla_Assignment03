package covariant_3;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   Animal animal = new Animal();
	        Animal dog = new Dog();

	        animal.getAnimal(); 
	        dog.getAnimal();
	    }

}
