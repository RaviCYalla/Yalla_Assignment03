package covariant_3;

 class Animal {

	  public Animal getAnimal() {
	        System.out.println("Animal class");
	        return new Animal();
	    }
}
